export interface EmployeePreference {
    id: number,
    gift: string
}