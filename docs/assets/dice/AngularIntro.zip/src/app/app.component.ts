import { Component, OnChanges, OnInit } from '@angular/core';
import { SharedService } from './SharedService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
//interpolation
//property binding
//form validation
export class AppComponent {
  title = 'Project1';
  id!: string;
  gifts: string[] = ['Audi', "Mercedes"];
  isSubmitted: boolean = false;

  constructor( private sharedService: SharedService){
    this.sharedService.setData(this.id);
  }
  
  onSubmit() {
    console.log('Submitted')
    this.isSubmitted = true;
    this.sharedService.setData(this.id);
    console.log('this.sharedService ->'+this.sharedService.getData())
  }

  onReset() {
    this.id = "";
  }

  onEvent(newEvent: any) {
    console.log("Received: " + newEvent);
  }

}
