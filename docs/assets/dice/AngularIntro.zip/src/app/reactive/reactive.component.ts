import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedService } from '../SharedService';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.scss']
})
export class ReactiveComponent implements OnInit{
  @Input() id = ""
  @Output() newEvent = new EventEmitter<string>();
  feedbackmessage: string = "";
  myForm!: FormGroup;
  
  constructor( private sharedService: SharedService){
    this.sharedService.setData(this.id);
  }

  ngOnInit(): void {
    this.myForm = new FormGroup({
      name: new FormControl(''),
      email: new FormControl('', [Validators.required, Validators.email]),
      message: new FormControl('',[Validators.required, Validators.minLength(15)])
    });
  }

  onSubmit() {
    console.log("Feedback submitted")
    console.log("Your feedback is " + this.myForm.get('message')?.value);
    this.newEvent.emit(this.feedbackmessage);
  }
}
